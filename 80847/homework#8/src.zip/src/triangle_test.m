tri = Triangle(1,2,3, [0;0], [1;0], [0;1], 1);
tri.vector_a
tri.vector_b
